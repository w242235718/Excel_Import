package w301.xyz.excel_import.mapper;

import org.apache.ibatis.annotations.Param;
import w301.xyz.excel_import.po.JourneyInfo;
import java.util.List;


public interface JourneyTableMapper {
    public List<JourneyInfo> getLatestByDate(@Param("date") String date);
}
