package w301.xyz.excel_import.po;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableEntity {
    private String filedName;
    private String filedValue;
}
