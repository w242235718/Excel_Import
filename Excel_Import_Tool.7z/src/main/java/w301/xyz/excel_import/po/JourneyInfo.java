package w301.xyz.excel_import.po;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JourneyInfo {
    private Long id;
    private String number;
    private String data_apply_time;
    private String operator;
    private String districts_counties;
    private String township;
    private String name;
    private String mobile;
    private String id_card_no;
    private String come_xin_time;
    private String source;
    private String base_station_location;
    private String imsi;
    private Date create_time;
    private Date update_time;
}
