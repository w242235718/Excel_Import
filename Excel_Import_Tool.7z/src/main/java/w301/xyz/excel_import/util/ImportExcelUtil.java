package w301.xyz.excel_import.util;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.text.csv.CsvData;
import cn.hutool.core.text.csv.CsvReader;
import cn.hutool.core.text.csv.CsvRow;
import cn.hutool.core.text.csv.CsvUtil;
import cn.hutool.poi.excel.sax.Excel03SaxReader;
import cn.hutool.poi.excel.sax.Excel07SaxReader;
import cn.hutool.poi.excel.sax.handler.RowHandler;
import com.alibaba.druid.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import w301.xyz.excel_import.po.TableEntity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class ImportExcelUtil {
    private static List<Map<String, Object>> datas = new ArrayList<>();
    private static List<List<TableEntity>> tableDatas=new ArrayList<>();
    private static List<Object> headLine = new ArrayList<>();
    public static char QUOTE=34;
    private static SimpleDateFormat sd=new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

    private static Integer sequenceId=0;

    //=================生成sql写入到磁盘===================================
    public static List readExcel(String filePath,Integer sheetIndex){
        tableDatas.clear();
        if (StringUtils.isEmpty(filePath)){
            throw new RuntimeException("文件路径为空");
        }
        if (sheetIndex<0){
            throw new RuntimeException("sheet不能小于0");
        }
        handlerReadByExt(filePath.substring(filePath.lastIndexOf(".")),filePath,sheetIndex);
        return tableDatas;
    }

    /**
     *
     * @param tableEnumClazz 映射关系枚举类
     * @param targetTable  目标表
     * @param tDates 数据源
     * @return
     * @param <T>
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static <T> List<T> transferToSqlEntity(Class tableEnumClazz,Class<T> targetTable,List<List<TableEntity>> tDates) throws InstantiationException, IllegalAccessException {
        int tDataCounts=tDates.size();
        List<T> sqlEntities=new ArrayList<>(tDates.size());

        for (int i = 0; i < tDataCounts; i++) {
            List<TableEntity> te = tDates.remove(0);
            if (CollectionUtils.isEmpty(te)){
                continue;
            }else{
                //获取反射赋值后的表实体对象
                T instance = getMappedTableEntity(tableEnumClazz, targetTable, te);
                sqlEntities.add(instance);
            }
        }
        return sqlEntities;
    }

    /**
     * 获取通过反射完成赋值的表实体对象
     * @param tableEnumClazz 字段与表关系映射
     * @param targetTable 目标表类
     * @param te
     * @return
     * @param <T>
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    private static <T> T getMappedTableEntity(Class tableEnumClazz, Class<T> targetTable, List<TableEntity> te) throws InstantiationException, IllegalAccessException {
        T instance = targetTable.newInstance();
        te.stream().forEach(tEntity->{
            boolean isCompatibleField=false;
            //枚举获取到字段名称
            if (!tableEnumClazz.isEnum()) {
                throw new RuntimeException(tableEnumClazz.getName()+",不是枚举类型!");
            }
            Object[] enumConstants = tableEnumClazz.getEnumConstants();
            for (Object enumObj : enumConstants) {
                //获取到字段
                try {
                    Class<?> enumClazz = enumObj.getClass();
                    Method enumFieldName = enumClazz.getDeclaredMethod("getFiledName");
                    Method enumField = enumClazz.getDeclaredMethod("getFiled");
                    String enumFieldNameStr = (String) enumFieldName.invoke(enumObj, null);
                    String enumFieldStr = (String) enumField.invoke(enumObj, null);
                    String tableFieldNameStr="";
                    //匹配字段
                    if (tEntity.getFiledName().equalsIgnoreCase(enumFieldNameStr)) {
                        isCompatibleField=true;
                        //驼峰转换
                        tableFieldNameStr=getCamelCaseFieldName(enumFieldStr);
                        //反射赋值
                        setMethodInvoke(targetTable, instance, tEntity, tableFieldNameStr);

                    }
                    if (!isCompatibleField){
                        //兼容性字段
                        for (CommonFieldMapping cfm : CommonFieldMapping.values()) {
                            if (cfm.getFiledName().equals(tEntity.getFiledName()) && cfm.getAnotherName().equals(enumFieldNameStr)) {
                                String anotherName = cfm.getAnotherName();
                                //获取tableFieldNameStr
                                tableFieldNameStr=getCamelCaseFieldName(enumFieldStr);
                                setMethodInvoke(targetTable, instance, tEntity, tableFieldNameStr);
                            }else{
                                continue;
                            }
                        }
                    }
                } catch (NoSuchMethodException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                } catch (NoSuchFieldException e) {
                    throw new RuntimeException(e);
                }


            }
        });
        return instance;
    }

    private static <T> void setMethodInvoke(Class<T> targetTable, T instance, TableEntity tEntity, String tableFieldNameStr) throws NoSuchFieldException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Method tableFieldMethod = getFieldSetMethod(targetTable, tableFieldNameStr);
        tableFieldMethod.invoke(instance, tEntity.getFiledValue());
    }

    private static <T> Method getFieldSetMethod(Class<T> targetTable, String tableFieldNameStr) throws NoSuchFieldException, NoSuchMethodException {
        Field tableField = targetTable.getDeclaredField(tableFieldNameStr);
        Class<?> filedType = tableField.getType();
        Method tableFieldMethod = targetTable.getDeclaredMethod(
                "set" + tableFieldNameStr.substring(0,1).toUpperCase()+ tableFieldNameStr.substring(1),
                filedType);
        return tableFieldMethod;
    }

    private static String getCamelCaseFieldName(String enumFieldStr){
        StringBuilder tableFieldName=new StringBuilder();

        String[] tbFieldNames = enumFieldStr.split("_");
        if (tbFieldNames.length>1){
            tableFieldName.append(tbFieldNames[0]);
            for (int i1 = 1; i1 < tbFieldNames.length; i1++) {
                tableFieldName.append(tbFieldNames[i1].substring(0,1).toUpperCase());
                tableFieldName.append(tbFieldNames[i1].substring(1));
            }
        }else{
            tableFieldName.append(enumFieldStr);
        }
        return tableFieldName.toString();
    }


    public static void clean(){
        datas=null;
        sequenceId=0;
        System.gc();
    }

    private static void handlerReadByExt(String extType, String filePath, Integer sheetIndex) {
        switch (extType) {
            case ".xlsx":
                Sax07Read(filePath,new ExcelSqlHandler(), sheetIndex);
                break;
            case ".xls":
                Sax03Read(filePath,new ExcelSqlHandler(), sheetIndex);
                break;
            case ".csv":
                CsvRead(filePath, sheetIndex, "utf8");
                break;
            default:
                throw new RuntimeException("出错了~!该格式不支持~");
        }
    }

    private static class ExcelSqlHandler implements RowHandler{
        @Override
        public void handle(int sheetIndex, long rowIndex, List<Object> rowCells) {
            List<TableEntity> tList=new LinkedList<>();
            //表头
            if (rowIndex==0L){
                headLine=rowCells;
            }
            if (rowIndex>0L) {
                tList.add(new TableEntity("序号",sequenceId.toString()));
                for (int i = 1; i < rowCells.size(); i++) {
                    String title = toStr(headLine.get(i));
                    String value = formatOfCommonFiledNumber(title,toStr(rowCells.get(i)));
                    TableEntity entity = new TableEntity(title,value);
                    tList.add(entity);
                }
                tableDatas.add(tList);
            }
            sequenceId++;
        }

        private String formatOfCommonFiledNumber(String title, String value) {
            String val;
            switch (title){
                case "证件号码":
                case "身份证号":
                    val=formatIdCard(value);
                    return val;
                default:
                    return value;
            }
        }

        private String formatIdCard(String value) {
            int index=-1;
            index=value.indexOf(39);
            index=value.indexOf(145);
            index=value.indexOf(222);
            index=value.indexOf('‘');
            if (index!=-1){
                return value.substring(index+1);
            }else{
                return value;
            }
        }
    }
    private static String toStr(Object obj){
        return obj==null?"":obj.toString().trim();
    }
    //==================写入到磁盘txt格式==================================
    public List<String> getTableEnumTitle(Class enumTableClazz){
        List<String> tableTitle=new ArrayList<>();
        if (enumTableClazz.isEnum()){
            Object[] enumConstants = enumTableClazz.getEnumConstants();
            if (enumConstants.length>0){
                try {
                    for (Object enumObj : enumConstants) {
                        if (!ObjectUtils.isEmpty(enumObj)) {
                            Method getFiled = enumObj.getClass().getDeclaredMethod("getFiled", null);
                            String result = (String) getFiled.invoke(enumObj, null);
                            tableTitle.add(result);
                        }
                    }
                } catch (NoSuchMethodException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return tableTitle;
    }

    /**
     * 读取excel数据 支持.csv .xls .xlsx格式
     * @param path
     * @param sheetIndex
     * @return
     */
    public static List<Map<String, Object>> readBigExcelToWrite(String path, Integer sheetIndex) {
        datas.clear();
        String extType = path.substring(path.lastIndexOf("."));
        handlerByExt(extType, path, sheetIndex);
        return datas;
    }

    /**
     * 将读取到的excel写出到硬盘
     * @param file
     * @param data
     */
    public  void WriteToDisk(File file, List<Map<String,Object>> data){
        try(BufferedWriter bw=new BufferedWriter(new FileWriter(file))) {
            writeTableTitle(bw,null);
            writeTableData(bw,data);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static void writeTableData(BufferedWriter bw, List<Map<String, Object>> data) throws IOException, InterruptedException {
        for (int i = 0; i < data.size(); i++) {
            Map<String, Object> tMap = data.get(i);
            bw.write(ImportExcelUtil.QUOTE+String.valueOf(i+1)+ImportExcelUtil.QUOTE+"\t");
            bw.write(tMap.get("数据报送时间")==null?"":tMap.get("数据报送时间").toString()+"\t");
            bw.write(tMap.get("运营商")==null?"":tMap.get("运营商").toString()+"\t");
            bw.write(tMap.get("区县")==null?"":tMap.get("区县").toString()+"\t");
            bw.write(tMap.get("乡镇")==null?"":tMap.get("乡镇").toString()+"\t");
            bw.write(tMap.get("姓名")==null?"":tMap.get("姓名").toString()+"\t");
            String phoneNumber;
            phoneNumber=tMap.get("手机号")==null?"":tMap.get("手机号").toString();
            if (phoneNumber==null || phoneNumber.length()<=0){
                phoneNumber=tMap.get("手机号码")==null?"":tMap.get("手机号码").toString();
            }
            bw.write(phoneNumber+"\t");
            String idCardNo;
            if ((idCardNo=tMap.get("证件号码").toString()).indexOf("‘")!=-1){
                idCardNo=QUOTE+idCardNo.substring(idCardNo.indexOf("‘")+1);
            }
            bw.write(idCardNo==null?"":idCardNo+"\t");
            bw.write(tMap.get("入新时间")==null?"":tMap.get("入新时间").toString()+"\t");
            bw.write(tMap.get("来源地")==null?"":tMap.get("来源地").toString()+"\t");
            bw.write(tMap.get("基站位置")==null?"":tMap.get("基站位置").toString()+"\t");
            bw.write(tMap.get("IMSI")==null?"":tMap.get("IMSI").toString()+"\t");
            bw.write(QUOTE+sd.format(new Date())+QUOTE+"\t");
            bw.write(QUOTE+sd.format(new Date())+QUOTE+"\t");
            bw.write("\n");
        }
    }

    private void writeTableTitle(BufferedWriter bw,Class tableTitleEnum) throws IOException {
        List<String> tableEnumTitle = getTableEnumTitle(JourneyInfoTableEnum.class);
        for (String title : tableEnumTitle) {
            bw.write(title+"\t");
        }
        bw.write("\n");
    }

    /**
     * @param extType
     * @param path
     * @param sheetIndex
     * @return Handler ClassName
     */
    private static void handlerByExt(String extType, String path, Integer sheetIndex) {
        switch (extType) {
            case ".xlsx":
                Sax07Read(path,new ExcelRowHandler(),sheetIndex);
                break;
            case ".xls":
                Sax03Read(path,new ExcelRowHandler(), sheetIndex);
                break;
            case ".csv":
                //todo:重写
                //CsvRead(path, sheetIndex, "utf8");
                break;
            default:
                throw new RuntimeException("出错了~!该格式不支持~");
        }
    }

    private static void CsvRead(String path, Integer sheetIndex, String charset) {
        try (CsvReader reader=CsvUtil.getReader()){
            CsvData data = reader.read(FileUtil.file(path), Charset.forName(charset));
            List<CsvRow> rows = data.getRows();
            handleCsvData(rows);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void handleCsvData(List<CsvRow> rows) {
        for (CsvRow row : rows) {
            List<String> rawList = row.getRawList();
            //csv表头
            if (rawList.get(0).equalsIgnoreCase("序号") || rawList.get(0).equalsIgnoreCase(" ")) {
                headLine = Collections.singletonList(rawList);
                continue;
            }
            //科学计数转环
            if (rawList.get(11)!=null && rawList.get(11).length()>0){
                toNormalNumber(rawList);
            }
            //添加数据
            HashMap<String, Object> tMap = new HashMap<>();
            for (int i = 0; i < rawList.size(); i++) {
                Object title = ((ArrayList) headLine.get(0)).get(i);
                tMap.put(title.toString(),QUOTE+rawList.get(i)+QUOTE);
            }
            datas.add(tMap);
        }
    }

    private static void toNormalNumber(List<String> rawList) {
        String imsiE = rawList.get(rawList.size() - 1);
        //长度上不满足科学计数法
        if (imsiE.length()<14){
            String val = new BigDecimal(imsiE).toBigInteger().toString(10);
            rawList.set(rawList.size() - 1, val);
            val = null;
        }else{
            rawList.set(rawList.size()-1, imsiE.trim());
        }

    }

    private static void Sax03Read(String path, RowHandler rowHandler,Integer sheetIndex) {
        Excel03SaxReader reader = new Excel03SaxReader(rowHandler);
        reader.read(path, sheetIndex);
    }

    private static void Sax07Read(String path, RowHandler rowHandler,Integer sheetIndex) {
        Excel07SaxReader reader = new Excel07SaxReader(rowHandler);
        reader.read(path, sheetIndex);
    }

    /**
     * todo:数据重复
     */
    private static class ExcelRowHandler implements RowHandler {
        @Override
        public void handle(int sheetIndex, long rowIndex, List<Object> rowList) {
            //表头
            boolean isContainSequence = false;
            if (rowIndex == 0) {
                headLine = rowList;
                if (headLine.get(0).equals(HeadLineConst.SEQUENCE_CN) || headLine.get(0).equals(" ")) {
                    isContainSequence = true;
                }
            }

            //读入数据
            if (isContainSequence) {
                handleExcelRow(rowIndex, rowList, 1);
            } else {
                handleExcelRow(rowIndex, rowList, 0);
            }

        }

        //先暂存map
        private void handleExcelRow(long rowIndex, List<Object> rowList, int index) {
            //数据非空判断
            if (rowList.stream().allMatch(row->Objects.isNull(row)||toStr(row).length()==0)){
                return;
            }
            Map<String, Object> tMap = new HashMap<>();
            tMap.put("序号", String.valueOf(rowIndex));
            //跳过表头
            if (!headLine.get(index).equals(rowList.get(index))) {
                for (int i = index; i < rowList.size(); i++) {
                    tMap.put(toStr(headLine.get(i)), QUOTE+toStr(rowList.get(i))+QUOTE);
                }
                datas.add(tMap);
            }
        }

        public static String toStr(Object item) {
            return item == null ? "" : item.toString().trim();
        }
    }


}
