package w301.xyz.excel_import.util;

public interface HeadLineConst {
    String SEQUENCE_CN="序号";
    String DATA_APPLY_TIME_CN="数据报送时间";
}
