package w301.xyz.excel_import.service.impl;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import w301.xyz.excel_import.mapper.KeyCrowdNucleicTableMapper;
import w301.xyz.excel_import.po.KeyCrowdNucleicAcid;
import w301.xyz.excel_import.service.KeyCrowdNucleicService;

import java.util.List;
@Transactional
@Service
public class KeyCrowdNucleicServiceImpl implements KeyCrowdNucleicService {
    @Autowired
    private SqlSessionFactory sqlSessionFactory;
    @Autowired
    private KeyCrowdNucleicTableMapper keyCrowdNucleicTableMapper;
    private static final int BATCH_SIZE=1000;

    @Override
    public Integer batchInsert(List<KeyCrowdNucleicAcid> datas) {
        //获得批处理器
        SqlSession batchSqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH,false);
        int affectRow=1;
        try {
            KeyCrowdNucleicTableMapper keyCrowdNucleicTableMapper = batchSqlSession.getMapper(KeyCrowdNucleicTableMapper.class);
            //数据总量
            int dateTotal= datas.size();
            int count=1;
            //遍历批量插入
            for (int i = 0; i < dateTotal; i++) {
                KeyCrowdNucleicAcid keyCrowdNac = datas.remove(0);
                if (keyCrowdNac==null){
                    continue;
                }else{
                    keyCrowdNucleicTableMapper.insertDataByBatch(keyCrowdNac);
                    if ((count%BATCH_SIZE==0)||count==dateTotal){
                        batchSqlSession.flushStatements();
                    }
                    count++;
                }
            }
            //提交事务
            affectRow=count;
            batchSqlSession.commit(!TransactionSynchronizationManager.isSynchronizationActive());
        }catch (Exception e){
            batchSqlSession.rollback();
        }
        finally {
            batchSqlSession.close();
            System.gc();
        }
        return affectRow;
    }

    /**
     * 查询最新一条日期数据记录
     * @param date
     * @return
     */
    @Override
    public List<KeyCrowdNucleicAcid> getLatestData(String date) {
        return keyCrowdNucleicTableMapper.getLatestByDate(date);
    }
}
