package w301.xyz.excel_import.service;

import org.apache.poi.ss.formula.functions.T;
import w301.xyz.excel_import.po.KeyCrowdNucleicAcid;

import java.util.List;

public interface KeyCrowdNucleicService extends BasicMapper<KeyCrowdNucleicAcid> {

}
