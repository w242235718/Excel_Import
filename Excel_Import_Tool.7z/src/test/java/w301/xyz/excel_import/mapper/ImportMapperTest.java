package w301.xyz.excel_import.mapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ImportMapperTest {

    @Test
    public void getLatestByDate() {
    }
}