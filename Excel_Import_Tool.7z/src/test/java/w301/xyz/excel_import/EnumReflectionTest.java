package w301.xyz.excel_import;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ObjectUtils;
import w301.xyz.excel_import.po.KeyCrowdNucleicAcid;
import w301.xyz.excel_import.service.KeyCrowdNucleicService;
import w301.xyz.excel_import.util.ImportExcelUtil;
import w301.xyz.excel_import.util.JourneyInfoTableEnum;
import w301.xyz.excel_import.util.KeyCrowdNucleicAcidTableEnumMapping;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
@SpringBootTest
public class EnumReflectionTest {
    @Autowired
    private KeyCrowdNucleicService crowdNucleicService;

    @Test
    public void test(){
        getTableEnumTitle(JourneyInfoTableEnum.class);
    }

    public List<String> getTableEnumTitle(Class enumTableClazz){
        List<String> tableTitle=new ArrayList<>();
        if (enumTableClazz.isEnum()){
            Object[] enumConstants = enumTableClazz.getEnumConstants();
            if (enumConstants.length>0){
                try {
                    for (Object enumObj : enumConstants) {
                        if (!ObjectUtils.isEmpty(enumObj)) {
                            Method getFiled = enumObj.getClass().getDeclaredMethod("getFiled", null);
                            String result = (String) getFiled.invoke(enumObj, null);
                            tableTitle.add(result);
                        }
                    }
                } catch (NoSuchMethodException e) {
                    throw new RuntimeException(e);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return tableTitle;
    }


    @Test
    public void testKeyCrowdNucleicAcidBatchImport(){
        List excelDates = ImportExcelUtil.readExcel("E:\\WorkData\\重点人员核算对比\\7.15风险职业和重点人群底数37249.xlsx", 0);
        try {
            List entityDates = ImportExcelUtil.transferToSqlEntity(KeyCrowdNucleicAcidTableEnumMapping.class, KeyCrowdNucleicAcid.class, excelDates);
            //调用Service方法完成批量插入
            Integer row = crowdNucleicService.batchInsert(entityDates);
            System.out.println(row);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testJourneyExcelBatchImport(){
        //excel读取多张表是否正常

        //将excel数据转环为po对象

        //分批插入数据库
    }
}
